function App() {
  return (
    <>
      <h1>Patatas</h1>
    </>
  );
}

export default App;
